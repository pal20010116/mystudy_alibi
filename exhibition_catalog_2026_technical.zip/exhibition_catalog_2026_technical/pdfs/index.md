# 掲載PDF一覧

PDFファイルを複製せず、出展者が掲載した資料への閲覧リンクを整理しています。オンライン接続が必要です。

| 展示会 | 出展者 | 製品・サービス | PDF | 掲載元 |
|---|---|---|---|---|
| JIMA2026（総合検査機器展） | 株式会社ASICON / Microworks GmbH | 非破壊検査向け: X線タルボ・ロー干渉計キット Talint-EDU | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=390) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=287) |
| JIMA2026（総合検査機器展） | アバールデータ | 医療分野、膜厚検査、科学分析システム向け最速6.4GSps 高速デジタイザ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=381) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=450) |
| JIMA2026（総合検査機器展） | アンリツ株式会社 | X線検査機 XR76シリーズ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=118) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=316) |
| JIMA2026（総合検査機器展） | アンリツ株式会社 | M6-hシリーズ 金属検出機 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=119) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=316) |
| JIMA2026（総合検査機器展） | アンリツ株式会社 | 産業用音響カメラ FLIR Siシリーズ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=121) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=316) |
| JIMA2026（総合検査機器展） | アンリツ株式会社 | 総合品質管理・制御システム QUICCA | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=122) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=316) |
| JIMA2026（総合検査機器展） | 株式会社飯田照明 | 紫外線LED照明 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=376) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=284) |
| JIMA2026（総合検査機器展） | 株式会社飯田照明 | 製品検査用LED照明 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=377) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=284) |
| JIMA2026（総合検査機器展） | インサイト株式会社 | 稼働中の設備を止めない、最大1000℃の超高温検査 （電磁超音波探触子） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=304) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=295) |
| JIMA2026（総合検査機器展） | インサイト株式会社 | 【空中超音波探傷】水に濡らせない検査対象の計測に。 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=511) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=295) |
| JIMA2026（総合検査機器展） | インサイト株式会社 | 【レーザー超音波探傷】過酷な現場の検査を解決するレーザー超音波探傷装置LUSシリーズ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=498) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=295) |
| JIMA2026（総合検査機器展） | ウーラジャパン株式会社 | 次世代配管カメラ VIS700シリーズ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=125) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=306) |
| JIMA2026（総合検査機器展） | ウーラジャパン株式会社 | 小型内視鏡カメラ ＶＥ４００ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=126) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=306) |
| JIMA2026（総合検査機器展） | ウーラジャパン株式会社 | ウーラ クリーニング機器 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=128) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=306) |
| JIMA2026（総合検査機器展） | ウーラジャパン株式会社 | 排ガスアナライザ A550インダストリアル | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=129) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=306) |
| JIMA2026（総合検査機器展） | 株式会社近畿レントゲン工業社 | X線検査装置のサブスクサービス「krix」 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=38) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=289) |
| JIMA2026（総合検査機器展） | 株式会社近畿レントゲン工業社 | X線受託撮影サービス | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=39) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=289) |
| JIMA2026（総合検査機器展） | 株式会社近畿レントゲン工業社 | 【汎用X線検査装置】ITX-S40T | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=41) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=289) |
| JIMA2026（総合検査機器展） | 株式会社近畿レントゲン工業社 | 汎用X線発生装置【240Wモノタンク】 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=42) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=289) |
| JIMA2026（総合検査機器展） | スマートビジョン(株) | Rayence CMOS パネル | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=396) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=307) |
| JIMA2026（総合検査機器展） | ダコタ・ジャパン株式会社 | 多用途Aスキャン超音波厚さ計 「CMX10-DL」 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=408) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=336) |
| JIMA2026（総合検査機器展） | ダコタ・ジャパン株式会社 | UCI硬さ計「Lab UCI Pro」 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=431) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=336) |
| JIMA2026（総合検査機器展） | ダコタ・ジャパン株式会社 | リバウンド硬さ計 「Lab Leeb」 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=432) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=336) |
| JIMA2026（総合検査機器展） | ダコタ・ジャパン株式会社 | ポータブルロックウェル硬さ計 「TKX LIGHT」 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=433) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=336) |
| JIMA2026（総合検査機器展） | ダコタ・ジャパン株式会社 | 電磁超音波厚さ計 「UT-3M-EMA」 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=434) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=336) |
| JIMA2026（総合検査機器展） | 中央精機株式会社 | ＯｐｔｏＮｕｍｅ® －見えなかった表面が、見える世界へ－ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=288) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=330) |
| JIMA2026（総合検査機器展） | つくばテクノロジー株式会社 | レーザー超音波可視化検査装置 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=24) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=317) |
| JIMA2026（総合検査機器展） | つくばテクノロジー株式会社 | 超小型冷陰極Ｘ線検査装置 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=371) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=317) |
| JIMA2026（総合検査機器展） | つくばテクノロジー株式会社 | 小型冷陰極Ｘ線検査装置 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=372) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=317) |
| JIMA2026（総合検査機器展） | テスコ株式会社 | 工業用X線CTスキャン受託サービス | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=59) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=312) |
| JIMA2026（総合検査機器展） | ディービー株式会社 | Explorer | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=46) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=347) |
| JIMA2026（総合検査機器展） | ディービー株式会社 | Pilot+ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=63) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=347) |
| JIMA2026（総合検査機器展） | ディービー株式会社 | Pilot Multi | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=64) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=347) |
| JIMA2026（総合検査機器展） | ディービー株式会社 | Explorer Max | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=65) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=347) |
| JIMA2026（総合検査機器展） | ディービー株式会社 | Pioneer Max | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=66) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=347) |
| JIMA2026（総合検査機器展） | トーレック株式会社 | 携帯型工業用Ⅹ線発生装置 RIX-MC-2シリーズ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=267) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=308) |
| JIMA2026（総合検査機器展） | 長野オートメーション株式会社 | GlobeScan・グローブスキャン・レーザースキャン計測ユニット | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=250) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=337) |
| JIMA2026（総合検査機器展） | 長野オートメーション株式会社 | GyroScan・ジャイロスキャン・レーザースキャン検査ユニット | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=252) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=337) |
| JIMA2026（総合検査機器展） | 日本電測機株式会社 | ポータブル渦流探傷器PECT-Ⅲ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=382) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=294) |
| JIMA2026（総合検査機器展） | 日本マテック株式会社 | FMC/TFM 2次元マルチ超音波探傷器 Dolphicam 2+ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=255) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=304) |
| JIMA2026（総合検査機器展） | 日本マテック株式会社 | FMC/TFM マルチアレイ超音波探傷器 A1550 IntroVisor | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=452) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=304) |
| JIMA2026（総合検査機器展） | 日本マテック株式会社 | コンクリート探傷用3D超音波探傷器 A1040 MIRA 3D PRO | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=454) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=304) |
| JIMA2026（総合検査機器展） | 日本マテック株式会社 | 亀裂深度計 RMG4015 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=460) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=304) |
| JIMA2026（総合検査機器展） | フジデノロ株式会社 | iMus MFI(Magnetic Field Imaging) 参考出展 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=383) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=327) |
| JIMA2026（総合検査機器展） | Hexagon Manufacturing Intelligence 株式会社 | VGSTUDIO MAX | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=445) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=340) |
| JIMA2026（総合検査機器展） | ポニー工業株式会社 | ベンダブルDR装置 HPX-ARC 1025PH（ケアストリームヘルス） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=488) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=293) |
| JIMA2026（総合検査機器展） | ポニー工業株式会社 | フェーズドアレイ電子機器内蔵型フェーズドアレイローラープローブ（ベーカーヒューズ・エナジージャパン） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=486) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=293) |
| JIMA2026（総合検査機器展） | ポニー工業株式会社 | 汎用自動UT装置 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=489) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=293) |
| JIMA2026（総合検査機器展） | ポニー工業株式会社 | 可搬型エリアモニタ PEMG型（コンテック） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=490) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=293) |
| JIMA2026（総合検査機器展） | 株式会社マーブル | 「さくっと、本気の品質DX」 検査データ活用で実現するQMS改革 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=71) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=351) |
| JIMA2026（総合検査機器展） | 合同会社ＭＩＲＩＮＥ | 超小型X線検査装置 「VEGARAYシリーズ」 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=185) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=320) |
| JIMA2026（総合検査機器展） | 合同会社ＭＩＲＩＮＥ | VEGARAY PRO（ベガレイ プロ） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=154) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=320) |
| JIMA2026（総合検査機器展） | 合同会社ＭＩＲＩＮＥ | VEGARAY（ベガレイ） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=155) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=320) |
| JIMA2026（総合検査機器展） | 合同会社ＭＩＲＩＮＥ | X線画像撮影サービス | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=156) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=320) |
| JIMA2026（総合検査機器展） | 株式会社ミルス・システムズ | 工業用内視鏡ビデオスコープ X750HD | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=193) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=319) |
| JIMA2026（総合検査機器展） | 株式会社ミルス・システムズ | 工業用内視鏡ビデオスコープ X2000HD | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=196) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=319) |
| JIMA2026（総合検査機器展） | 株式会社ミルス・システムズ | 工業用内視鏡ビデオスコープ X3000HD | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=197) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=319) |
| JIMA2026（総合検査機器展） | 株式会社ミルス・システムズ | ポールカメラ パン・チルト機能付き | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=198) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=319) |
| JIMA2026（総合検査機器展） | 株式会社ミルス・システムズ | ハイビジョン管内検査カメラ HD-MILS-2830 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=199) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=319) |
| JIMA2026（総合検査機器展） | 株式会社明電舎 | 冷陰極X線管の特長 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=260) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=339) |
| JIMA2026（総合検査機器展） | 株式会社明電舎 | 冷陰極X線管搭載 X線源 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=262) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=339) |
| JIMA2026（総合検査機器展） | ローデ・シュワルツ・ジャパン株式会社 | イメージングスキャナー R&S Imager | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=378) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=350) |
| センサエキスポジャパン2026 | 愛知製鋼株式会社 | 異物検査装置 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=513) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=198) |
| センサエキスポジャパン2026 | 愛知製鋼株式会社 | モータ異常検知 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=70) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=198) |
| センサエキスポジャパン2026 | 愛知製鋼株式会社 | LBワイヤ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=545) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=198) |
| センサエキスポジャパン2026 | 愛知製鋼株式会社 | 高感度シリーズ Type DJ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=67) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=198) |
| センサエキスポジャパン2026 | 株式会社アプロリンク | OPSENS社 光ファイバセンサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=230) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=179) |
| センサエキスポジャパン2026 | 株式会社アプロリンク | Merit Sensor社 MEMS圧力センサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=231) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=179) |
| センサエキスポジャパン2026 | 株式会社アプロリンク | AT SENSORS社 ３Ｄプロファイラ ３Ｄセンサカメラ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=232) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=179) |
| センサエキスポジャパン2026 | 株式会社アプロリンク | サーマルセンサ・温度センサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=234) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=179) |
| センサエキスポジャパン2026 | 株式会社アプロリンク | Ximea社 (超小型USBカメラ・研究開発用カメラ） xiMUシリーズ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=235) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=179) |
| センサエキスポジャパン2026 | イナバゴム株式会社 | 薄膜型感圧導電ゴムセンサー | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=307) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=161) |
| センサエキスポジャパン2026 | イナバゴム株式会社 | 3D曲面追従型圧力分布計測システム | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=491) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=161) |
| センサエキスポジャパン2026 | 入一通信工業株式会社 | 配線・電池交換不要！ペロブスカイト太陽電池搭載 温湿度CO2センサー | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=12) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=190) |
| センサエキスポジャパン2026 | 入一通信工業株式会社 | 水質を遠隔監視！故障防止と味を守るスマートTDSメーター | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=13) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=190) |
| センサエキスポジャパン2026 | 入一通信工業株式会社 | ルート最適化で残業削減！IoTボンベ残圧監視装置 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=14) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=190) |
| センサエキスポジャパン2026 | 株式会社岩田製作所 | センサブラケット＜当日出荷！＞ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=180) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=209) |
| センサエキスポジャパン2026 | エコーテック株式会社 | 超音波振動子・圧電セラミックス | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=157) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=175) |
| センサエキスポジャパン2026 | エコーテック株式会社 | ホビー用超音波カッターZOシリーズ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=158) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=175) |
| センサエキスポジャパン2026 | グローバル電子株式会社 ／グローバルマイクロニクス株式会社 ／応用電子工業株式会社 ／株式会社ニッポー | 耐腐食性に優れたセラミック圧力センサMetallux | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=114) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=173) |
| センサエキスポジャパン2026 | グローバル電子株式会社 ／グローバルマイクロニクス株式会社 ／応用電子工業株式会社 ／株式会社ニッポー | 高精度センサ・制御基板の開発から製造まで一貫対応 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=266) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=173) |
| センサエキスポジャパン2026 | KOA株式会社 | 多点風速計 Windgraphy®気流計測システム | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=324) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=159) |
| センサエキスポジャパン2026 | 株式会社CyberneX | XHOLOS Ear Brain Interface（エクゾロス） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=462) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=192) |
| センサエキスポジャパン2026 | 株式会社CyberneX | 脳情報活用支援プログラム Works with XHOLOS | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=463) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=192) |
| センサエキスポジャパン2026 | 株式会社CyberneX | リラックス度計測システム α Relax Analyzer | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=464) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=192) |
| センサエキスポジャパン2026 | 有限会社シスコム | 高精度デジタル温湿度センサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=29) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=165) |
| センサエキスポジャパン2026 | 有限会社シスコム | 触覚アレイセンサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=5) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=165) |
| センサエキスポジャパン2026 | 有限会社シスコム | 多点風速温度センサシステム | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=30) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=165) |
| センサエキスポジャパン2026 | 有限会社シスコム | 小型加振器（汎用タイプ） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=1) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=165) |
| センサエキスポジャパン2026 | 有限会社シスコム | リアルタイム 振動測定システム | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=92) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=165) |
| センサエキスポジャパン2026 | シチズンファインデバイス株式会社 | 光で非破壊計測し、狭所でも使える革新的な電流センサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=514) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=183) |
| センサエキスポジャパン2026 | 新光技研株式会社 ／heracle GmbH | 超高温 耐熱光ファイバ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=299) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=163) |
| センサエキスポジャパン2026 | 新光技研株式会社 ／heracle GmbH | 大口径石英光ファイバ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=298) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=163) |
| センサエキスポジャパン2026 | 株式会社ソフトエイジェンシー | SuguIoT 4-20 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=312) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=203) |
| センサエキスポジャパン2026 | 太平貿易株式会社 | InGaAs PIN Detectors | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=397) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=207) |
| センサエキスポジャパン2026 | ダイキンファインテック株式会社 | PICLIA圧電ワイヤーセンサー | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=25) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=164) |
| センサエキスポジャパン2026 | ダイキンファインテック株式会社 | PICLIAリボンデュアルセンサー | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=27) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=164) |
| センサエキスポジャパン2026 | 東京電機大学 石井研究室（ナノマテリアル研究室） | ZnGa2O4ナノ粒子薄膜による放射線・短波長紫外線センシング | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=84) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=222) |
| センサエキスポジャパン2026 | 東京電機大学 染矢研究室（熱流体システム研究室） | 極低温～1000℃超：熱と流れを視える化 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=297) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=223) |
| センサエキスポジャパン2026 | 新潟大学 マイクロマシン工学研究室 | 素材から生体まで～MEMSセンサで粘弾性・摩擦感をその場計測 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=309) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=224) |
| センサエキスポジャパン2026 | フジトク株式会社 | 台湾製の圧力製品 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=427) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=202) |
| センサエキスポジャパン2026 | モバイルコンピューティング推進コンソーシアム（MCPC） | センサの基礎を学ぼう！IoT技術テキストよりセンサ部分の抜粋冊子 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=164) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=212) |
| センサエキスポジャパン2026 | モバイルコンピューティング推進コンソーシアム（MCPC） | IoTシステム技術検定 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=165) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=212) |
| センサエキスポジャパン2026 | モバイルコンピューティング推進コンソーシアム（MCPC） | フィジカルAI入門（MCPC人材育成委員会冊子） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=246) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=212) |
| センサエキスポジャパン2026 | モバイルコンピューティング推進コンソーシアム（MCPC） | IoT開発を最速で始める超小型IoT開発キット「Leafony Pro Kit」 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=167) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=212) |
| センサエキスポジャパン2026 | モバイルコンピューティング推進コンソーシアム（MCPC） | モバイルバッテリー安全性・品質ガイドライン【自己適合宣言制度】 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=168) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=212) |
| センサエキスポジャパン2026 | ユニパルス株式会社 | 回転トルクメータ UTM | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=186) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=178) |
| センサエキスポジャパン2026 | ユニパルス株式会社 | 電動トルクアクチュエータ ユニサーボ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=187) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=178) |
| センサエキスポジャパン2026 | ユニパルス株式会社 | 非接触変位計 PS-IA | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=189) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=178) |
| センサエキスポジャパン2026 | 株式会社レプトリノ | 6軸力覚センサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=178) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=156) |
| センサエキスポジャパン2026 | 株式会社レプトリノ | 切削動力計 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=181) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=156) |
| センサエキスポジャパン2026 | 株式会社レプトリノ | フォースプレート | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=182) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=156) |
| センサエキスポジャパン2026 | 株式会社和貴研究所 | マルチセンサ(無線)データロガー"MSR" | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=6) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=157) |
| センサエキスポジャパン2026 | 株式会社和貴研究所 | 防水耐熱 BT無線データロガー"BlueWave" | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=7) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=157) |
| センサエキスポジャパン2026 | 株式会社和貴研究所 | ピエゾフイルムシート(PVDF) | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=8) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=157) |
| センサエキスポジャパン2026 | 株式会社和貴研究所 | ライフサイエンス・産業・食品用 超小型ロガー | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=9) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=157) |
| センサエキスポジャパン2026 | 株式会社和貴研究所 | 磁気特性測定装置『XacQuan』 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=11) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=157) |
| INTERMEASURE2026（計量計測展） | アンリツ株式会社 | XR76シリーズ X線検査機 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=105) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=281) |
| INTERMEASURE2026（計量計測展） | アンリツ株式会社 | M6-hシリーズ 金属検出機 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=106) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=281) |
| INTERMEASURE2026（計量計測展） | アンリツ株式会社 | 産業用音響カメラ FLIR Siシリーズ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=117) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=281) |
| INTERMEASURE2026（計量計測展） | アンリツ株式会社 | 総合品質管理・制御システム QUICCA | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=115) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=281) |
| INTERMEASURE2026（計量計測展） | 株式会社大手技研 | JCSS校正サービス | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=142) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=231) |
| INTERMEASURE2026（計量計測展） | 株式会社大手技研 | FLUKE 圧力コントローラー・校正器／気体流量校正システム 製品ガイド | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=141) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=231) |
| INTERMEASURE2026（計量計測展） | 株式会社大手技研 | 8270A / 8370A モジュラー 圧力コントローラー/ 圧力校正器 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=139) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=231) |
| INTERMEASURE2026（計量計測展） | 株式会社大手技研 | molbloc / molbox2 気体流量校正システム | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=140) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=231) |
| INTERMEASURE2026（計量計測展） | 株式会社大手技研 | 高速シーリング 着脱ツール『FasTestクイックカプラー』 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=143) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=231) |
| INTERMEASURE2026（計量計測展） | 株式会社オーバル | 水素実ガス校正 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=147) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=232) |
| INTERMEASURE2026（計量計測展） | 株式会社オーバル | 液体用電池駆動式クランプオン形超音波流量計UC-1 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=145) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=232) |
| INTERMEASURE2026（計量計測展） | 株式会社オーバル | スマート封印システム Lock'n Lorry® | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=146) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=232) |
| INTERMEASURE2026（計量計測展） | 株式会社共和電業 | 配線の悩みを解消！最大16CHの多点無線計測を実現する「MT-100シリーズ」 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=270) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=234) |
| INTERMEASURE2026（計量計測展） | 株式会社ケツト科学研究所 | インライン型近赤外水分計 KB-30 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=409) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=236) |
| INTERMEASURE2026（計量計測展） | 株式会社ケツト科学研究所 | 近赤外成分計KB-270 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=410) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=236) |
| INTERMEASURE2026（計量計測展） | 株式会社ケツト科学研究所 | 膜厚計 L-600 Standard/Expert | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=411) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=236) |
| INTERMEASURE2026（計量計測展） | 株式会社ケツト科学研究所 | 非接触膜厚測定器 コートマスターFLEX | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=412) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=236) |
| INTERMEASURE2026（計量計測展） | 株式会社ケツト科学研究所 | 赤外線水分計 FD-800 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=413) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=236) |
| INTERMEASURE2026（計量計測展） | GOLDEN MOUNTAIN ENTERPRISE CO. ,LTD. | Quality products | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=483) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=270) |
| INTERMEASURE2026（計量計測展） | GOLDEN MOUNTAIN ENTERPRISE CO. ,LTD. | For Natural gas boiler product | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=482) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=270) |
| INTERMEASURE2026（計量計測展） | GOLDEN MOUNTAIN ENTERPRISE CO. ,LTD. | Pressure switch | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=487) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=270) |
| INTERMEASURE2026（計量計測展） | GOLDEN MOUNTAIN ENTERPRISE CO. ,LTD. | INCREASED SAFETY TYPE CONDUIT HUB | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=485) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=270) |
| INTERMEASURE2026（計量計測展） | 株式会社信州TLO（埼玉大学／公立諏訪東京理科大学／東京電機大学） | マクロファージ分極化識別センサー分子（埼玉大学） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=215) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=274) |
| INTERMEASURE2026（計量計測展） | 株式会社信州TLO（埼玉大学／公立諏訪東京理科大学／東京電機大学） | 5G電波による屋内測位技術（公立諏訪東京理科大学） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=216) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=274) |
| INTERMEASURE2026（計量計測展） | 株式会社信州TLO（埼玉大学／公立諏訪東京理科大学／東京電機大学） | ZnGa2O4ナノ粒子薄膜による放射線センシング（東京電機大学） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=217) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=274) |
| INTERMEASURE2026（計量計測展） | 株式会社信州TLO（信州大学 医学部・理学部・工学部） | 唾液中カンジダ菌PCR定量による 健康・免疫力の測定方法 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=282) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=275) |
| INTERMEASURE2026（計量計測展） | 株式会社信州TLO（信州大学 医学部・理学部・工学部） | 高精度な同位体分析方法 ～微小固体を真空下で局所ガス化～ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=283) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=275) |
| INTERMEASURE2026（計量計測展） | 株式会社信州TLO（信州大学 医学部・理学部・工学部） | 文化財の非破壊耐震診断技術 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=219) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=275) |
| INTERMEASURE2026（計量計測展） | 株式会社信州TLO（信州大学 繊維学部） | その官能基量、「たぶん多いはず」で判断していませんか？（表面荷電基定量キット ChargeDAS） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=194) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=276) |
| INTERMEASURE2026（計量計測展） | 株式会社信州TLO（信州大学 繊維学部） | 匂いから、要救助者を探し出す／匂い源探査ドローン・匂いセンサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=195) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=276) |
| INTERMEASURE2026（計量計測展） | 株式会社センシズ | 小型圧力センサ HL | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=135) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=247) |
| INTERMEASURE2026（計量計測展） | 株式会社センシズ | チタン製小型圧力センサ ZL | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=148) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=247) |
| INTERMEASURE2026（計量計測展） | 株式会社センシズ | コネクタ型圧力センサ CL | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=149) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=247) |
| INTERMEASURE2026（計量計測展） | 株式会社センシズ | 投げ込み式水位センサ HM-200/HM-300 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=150) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=247) |
| INTERMEASURE2026（計量計測展） | 株式会社センシズ | 投げ込み式水位センサ HM-600/HM-700 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=151) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=247) |
| INTERMEASURE2026（計量計測展） | 株式会社ソニック | WAM-100型3次元超音波風向風速温度計 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=475) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=248) |
| INTERMEASURE2026（計量計測展） | 東京計器株式会社 | ポータブル超音波流量計 UFP-30 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=469) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=254) |
| INTERMEASURE2026（計量計測展） | 東京計器株式会社 | 液体用電池駆動式 クランプオン形超音波流量計 UC-1 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=471) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=254) |
| INTERMEASURE2026（計量計測展） | 東京計器株式会社 | 少量危険物倉庫・保管庫 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=472) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=254) |
| INTERMEASURE2026（計量計測展） | 東京計器株式会社 | リチウムイオン電池火災延焼防止 LiGIS 延焼防止剤 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=474) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=254) |
| INTERMEASURE2026（計量計測展） | 東京計装株式会社 | マスフローメータ/マスフローコントローラ NM-2000 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=90) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=255) |
| INTERMEASURE2026（計量計測展） | 東京計装株式会社 | クランプオン超音波流量計 UL100C | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=95) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=255) |
| INTERMEASURE2026（計量計測展） | 東京計装株式会社 | 防爆形電磁流量計 MAGMAX®4300C-JEx | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=96) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=255) |
| INTERMEASURE2026（計量計測展） | 東京計装株式会社 | クランプオン超音波流量計 SONICMAX® UL6300V2 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=87) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=255) |
| INTERMEASURE2026（計量計測展） | トキコシステムソリューションズ株式会社 | 緊急遮断弁 感震器信号式（MBD） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=531) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=256) |
| INTERMEASURE2026（計量計測展） | トキコシステムソリューションズ株式会社 | ポッターメーター | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=532) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=256) |
| INTERMEASURE2026（計量計測展） | トキコシステムソリューションズ株式会社 | クランプオン超音波流量計 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=533) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=256) |
| INTERMEASURE2026（計量計測展） | 長野計器株式会社 | SU71-D□□ IO-Link対応サニタリ圧力センサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=253) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=258) |
| INTERMEASURE2026（計量計測展） | 長野計器株式会社 | KD10 防爆構造光学式溶融樹脂 圧力・温度センサ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=254) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=258) |
| INTERMEASURE2026（計量計測展） | 日本フローセル株式会社 | 差圧式瞬間流量計 フローセル流量計 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=102) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=260) |
| INTERMEASURE2026（計量計測展） | 日本フローセル株式会社 | 定流量弁（設定流量固定型） リンセルバルブ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=103) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=260) |
| INTERMEASURE2026（計量計測展） | 国立研究開発法人日本原子力研究開発機構 | 放射性ストロンチウムの選択検知が可能なチェレンコフ検出器 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=296) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=279) |
| INTERMEASURE2026（計量計測展） | 一般財団法人日本品質保証機構 | ISO/IEC 17025の要求を満たした校正機関（JCSS、A2LA） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=292) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=262) |
| INTERMEASURE2026（計量計測展） | 一般財団法人日本品質保証機構 | JQA計測セミナー（教育支援） | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=293) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=262) |
| INTERMEASURE2026（計量計測展） | 一般財団法人日本品質保証機構 | 校正証明書等デジタル発行サービス | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=294) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=262) |
| INTERMEASURE2026（計量計測展） | 一般財団法人日本品質保証機構 | 主要校正取扱品目一覧 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=295) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=262) |
| INTERMEASURE2026（計量計測展） | HIKMICRO | 音響カメラ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=366) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=271) |
| INTERMEASURE2026（計量計測展） | 兵田計器工業株式会社 | トップランナー変圧器用ダイヤル温度計 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=81) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=264) |
| INTERMEASURE2026（計量計測展） | 兵田計器工業株式会社 | ハイブリッド式ダイヤル温度計 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=82) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=264) |
| INTERMEASURE2026（計量計測展） | 兵田計器工業株式会社 | 変圧器用保護機器 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=83) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=264) |
| INTERMEASURE2026（計量計測展） | 兵田計器工業株式会社 | 開閉器用保護機器 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=85) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=264) |
| INTERMEASURE2026（計量計測展） | 兵田計器工業株式会社 | 鉄道車両変圧器用保護機器 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=88) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=264) |
| INTERMEASURE2026（計量計測展） | 株式会社ビッツ | 校正業務の脱Excel、脱属人化を実現するWebアプリ | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=277) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=263) |
| INTERMEASURE2026（計量計測展） | 株式会社ビッツ | 探したいモノを探さずに見つける位置測位ソリューション | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=278) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=263) |
| INTERMEASURE2026（計量計測展） | 株式会社フクダ | Item 1 : JMIF022規格品 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=424) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=283) |
| INTERMEASURE2026（計量計測展） | 株式会社フクダ | Item 2 : JCSS認定校正 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=425) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=283) |
| INTERMEASURE2026（計量計測展） | 株式会社フクダ | Item 3 : ISO/IEC17025認定校正 | [PDFを開く](https://www.expo-form.com/united2026/usr_pdf.php?ss_cd=426) | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=283) |
