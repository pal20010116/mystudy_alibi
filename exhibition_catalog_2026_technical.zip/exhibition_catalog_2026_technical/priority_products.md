# 注目製品候補 — 技術的新規性・定量差分の確認優先リスト

> 製品名と主催者掲載情報に、新規性・小型化・高速化・非接触・AI・自動化などの差別化表現がある展示だけを抽出しています。点数は「ブースで詳しく聞く優先度」を付けるための便宜的な指標で、製品性能の優劣そのものではありません。

| 優先度 | 展示会 | 出展者 | 小間 | 製品・サービス | 抽出理由 | 掲載元 |
|---:|---|---|---|---|---|---|
| A (19) | JIMA2026（総合検査機器展） | キヤノンマーケティングジャパン株式会社 | J-52 | [新技術・新製品セミナー｜9月16日（水）13:30～14:15「半導体・電池向けSigray最先端X線解析ソリューション提案」](https://sigray.com/xrm-gallery/) | 新製品／新技術／最先端 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=355) |
| B (12) | JIMA2026（総合検査機器展） | 株式会社リガク | 番号未掲載 | 超高分解能CT | 新製品／超高分解能 | [一覧](https://www.expo-form.com/united2026/usr_list.php?exh=1) |
| B (10) | センサエキスポジャパン2026 | モバイルコンピューティング推進コンソーシアム（MCPC） | S-62 | IoT開発を最速で始める超小型IoT開発キット「Leafony Pro Kit」 | 最速／超小型 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=212) |
| B (8) | JIMA2026（総合検査機器展） | アンリツ株式会社 | J-35,I-20 | [X線検査機 XR76シリーズ](https://www.anritsu.com/ja-jp/product-inspection/products/x-ray/xr76) | メーカー公式追加確認 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=316) |
| B (8) | JIMA2026（総合検査機器展） | アンリツ株式会社 | J-35,I-20 | [産業用音響カメラ FLIR Siシリーズ](https://www.anritsu.com/ja-jp/product-inspection/products/solutions-for-food/production-equipment-maintenance/flir) | メーカー公式追加確認 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=316) |
| B (8) | INTERMEASURE2026（計量計測展） | アンリツ株式会社 | I-20,J-35 | [産業用音響カメラ FLIR Siシリーズ](https://www.anritsu.com/ja-jp/product-inspection/products/solutions-for-food/production-equipment-maintenance/flir) | メーカー公式追加確認 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=281) |
| C (7) | JIMA2026（総合検査機器展） | インサイト株式会社 | J-12 | [稼働中の設備を止めない、最大1000℃の超高温検査 （電磁超音波探触子）](https://insightkk.xsrv.jp/products/%e8%b6%85%e9%9f%b3%e6%b3%a2%e6%8e%a2%e8%a7%a6%e5%ad%90/emat) | 最大1000℃ | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=295) |
| C (7) | JIMA2026（総合検査機器展） | テスコ株式会社 | J-31 | [高精度ハンドヘルドスキャナ T‑SCAN hawk 2](https://www.tesco-ndt.co.jp/products/t-scan/) | ハンドヘルド／高精度 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=312) |
| C (7) | JIMA2026（総合検査機器展） | 日本電磁測器株式会社 | J-09 | AI自動画像処理検査 | AI／自動 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=292) |
| C (6) | JIMA2026（総合検査機器展） | アバールデータ | J-17 | [医療分野、膜厚検査、科学分析システム向け最速6.4GSps 高速デジタイザ](https://www.avaldata.co.jp/products/analog/category/highSpeedADConvertBoard) | 最速 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=450) |
| C (6) | JIMA2026（総合検査機器展） | ウーラジャパン株式会社 | J-25 | [次世代配管カメラ VIS700シリーズ](https://www.wohler.co.jp/shop/products/inspection-systems/inspection-cameras/vis-750-hd-inspection-camera-jp.html) | 次世代 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=306) |
| C (6) | JIMA2026（総合検査機器展） | 中外テクノス株式会社 | J-73 | フェーズドアレイ方式次世代水浸UT検査システム | 次世代 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=352) |
| C (5) | センサエキスポジャパン2026 | 太平貿易株式会社 | S-56 | [超高速 CO2センサ](https://www.taiheiboeki.co.jp/sensor_measuring-instrument/co2-sensor/gss/) | 超高速 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=207) |
| C (4) | JIMA2026（総合検査機器展） | Maplepix株式会社 | J-63 | AI自律化 | AI | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=342) |
| C (4) | JIMA2026（総合検査機器展） | つくばテクノロジー株式会社 | J-36 | [超小型冷陰極Ｘ線検査装置](https://www.tsukubatech.co.jp/neiren_show.php%3Fid=283.html) | 超小型 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=317) |
| C (4) | センサエキスポジャパン2026 | アーズ株式会社 | S-43 | [ソフトウェア受託 × AI駆動開発](https://arsjp.com/solutions/software/software.html) | AI | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=195) |
| C (4) | JIMA2026（総合検査機器展） | ダコタ・ジャパン株式会社 | J-57 | [ポータブルロックウェル硬さ計 「TKX LIGHT」](https://www.dakotajapan.com/product/p_h_tester/tkx-light/) | ポータブル | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=336) |
| C (4) | JIMA2026（総合検査機器展） | テスコ株式会社 | J-31 | [ポータブルX線CT装置 TXS-CT90/130](https://www.tesco-ndt.co.jp/products/portable/) | ポータブル | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=312) |
| C (4) | JIMA2026（総合検査機器展） | トーレック株式会社 | J-27 | [携帯型工業用Ⅹ線発生装置 RIX-MC-2シリーズ](https://toreck.co.jp/industrial/rix-mc.html) | 携帯型 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=308) |
| C (4) | センサエキスポジャパン2026 | モバイルコンピューティング推進コンソーシアム（MCPC） | S-62 | フィジカルAI入門（MCPC人材育成委員会冊子） | AI | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=212) |
| C (4) | センサエキスポジャパン2026 | ユニパルス株式会社 | S-26 | [非接触変位計 PS-IA](https://www.unipulse.tokyo/productitems/loadcell/) | 非接触 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=178) |
| C (4) | JIMA2026（総合検査機器展） | 合同会社ＭＩＲＩＮＥ | J-39 | [超小型X線検査装置 「VEGARAYシリーズ」](https://www.vegaray.jp/) | 超小型 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=320) |
| C (4) | JIMA2026（総合検査機器展） | 富士フイルム株式会社 | 番号未掲載 | デジタルRT画像のAI像質評価・判定 | AI | [一覧](https://www.expo-form.com/united2026/usr_list.php?exh=1) |
| C (4) | JIMA2026（総合検査機器展） | 日本マテック株式会社 | J-22 | ポータブル小型渦流探傷器 PockET | ポータブル | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=304) |
| C (4) | JIMA2026（総合検査機器展） | 日本電測機株式会社 | J-11 | ポータブル渦流探傷器PECT-Ⅲ | ポータブル | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=294) |
| C (4) | INTERMEASURE2026（計量計測展） | 東京計器株式会社 | I-29 | [ポータブル超音波流量計 UFP-30](https://www.tokyokeiki.jp/products/detail.html?pdid=352&TabModule889=4) | ポータブル | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=254) |
| C (4) | INTERMEASURE2026（計量計測展） | 株式会社AI技研（静岡大学発ベンチャー） | I-49 | 計測データによる設備状態判定・異常検知AI | AI | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=273) |
| C (4) | INTERMEASURE2026（計量計測展） | 株式会社AI技研（静岡大学発ベンチャー） | I-49 | AI導入の研究開発・コンサルティング | AI | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=273) |
| C (4) | センサエキスポジャパン2026 | 株式会社アプロリンク | S-27 | [Ximea社 (超小型USBカメラ・研究開発用カメラ） xiMUシリーズ](https://www.aprolink.jp/products/ximu-2) | 超小型 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=179) |
| C (4) | INTERMEASURE2026（計量計測展） | 株式会社ケツト科学研究所 | I-12 | [非接触膜厚測定器 コートマスターFLEX](https://www.kett.co.jp/products/coatmasterflex/) | 非接触 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=236) |
| C (4) | センサエキスポジャパン2026 | 株式会社スペースフォトン | S-53 | 超小型グリッドパターン投光器 | 超小型 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=204) |
| C (4) | JIMA2026（総合検査機器展） | 株式会社リガテック | J-19 | [工業用ポータブルX線発生器 RFシリーズ](https://rigatec.co.jp/products/rf-egm2/) | ポータブル | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=301) |
| C (4) | センサエキスポジャパン2026 | 株式会社光響 | S-48 | [ハンドヘルド型 LiDAR LiGrip SE ｜ GreenValley International](https://www.symphotony.com/lidar/greenvalley/ligripse/) | ハンドヘルド | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=199) |
| C (4) | センサエキスポジャパン2026 | 株式会社和貴研究所 | S-04 | [ライフサイエンス・産業・食品用 超小型ロガー](https://waki-bg.jp/datalogger/nano-oddi/) | 超小型 | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=157) |
| C (4) | JIMA2026（総合検査機器展） | 株式会社検査技術研究所 | 番号未掲載 | 超小型超音波探触子シリーズ | 超小型 | [一覧](https://www.expo-form.com/united2026/usr_list.php?exh=1) |
| C (4) | JIMA2026（総合検査機器展） | 株式会社近畿レントゲン工業社 | J-06 | [X線検査装置のサブスクサービス「krix」](https://x-raykinki.co.jp/ndt_subsc/) | サブスク | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=289) |
| C (4) | JIMA2026（総合検査機器展） | 株式会社近畿レントゲン工業社 | J-06 | [ポータブルX線照射器 AirRayプラス](https://x-raykinki.co.jp/product_airray_ndt/) | ポータブル | [詳細](https://www.expo-form.com/united2026/usr_detail.php?ucd=289) |